# 桌面字母索引常显 (LSPosed 模块)

## 编译(GitHub Actions,手机浏览器即可)
1. 在 github.com 新建一个仓库(Private 也行)。
2. 把本压缩包解压后的所有文件上传到仓库(注意要包含隐藏目录 .github)。
3. 打开仓库的 Actions 页面,等 build 跑完(约 3~5 分钟),
   在该次运行页面底部 Artifacts 下载 AlwaysLetterBar-apk。
4. 解压得到 app-debug.apk,安装。

## 启用
LSPosed → 模块 → 开启「桌面字母索引常显」→ 作用域勾选「系统桌面 (com.meizu.flyme.launcher)」
→ 强制停止桌面(或重启手机)。

## 排查
LSPosed → 日志,搜索 AlwaysLetterBar,应看到 "hooks installed";
若有 "hook failed" 把整行发给我。
