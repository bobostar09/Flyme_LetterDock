package de.robv.android.xposed;
public final class XposedHelpers {
    public static Class<?> findClass(String name, ClassLoader cl) { throw new RuntimeException("Stub!"); }
    public static XC_MethodHook.MethodHookParam dummy() { return null; }
    public static Object findAndHookMethod(Class<?> clazz, String method, Object... args) { throw new RuntimeException("Stub!"); }
    public static Object findAndHookMethod(String clazz, ClassLoader cl, String method, Object... args) { throw new RuntimeException("Stub!"); }
    public static Object findAndHookConstructor(String clazz, ClassLoader cl, Object... args) { throw new RuntimeException("Stub!"); }
    public static Object getObjectField(Object obj, String name) { throw new RuntimeException("Stub!"); }
    public static int getIntField(Object obj, String name) { throw new RuntimeException("Stub!"); }
    public static boolean getBooleanField(Object obj, String name) { throw new RuntimeException("Stub!"); }
    public static void setBooleanField(Object obj, String name, boolean value) { throw new RuntimeException("Stub!"); }
}
