package de.robv.android.xposed;
public final class XposedBridge {
    public static void log(String text) { throw new RuntimeException("Stub!"); }
    public static void log(Throwable t) { throw new RuntimeException("Stub!"); }
}
