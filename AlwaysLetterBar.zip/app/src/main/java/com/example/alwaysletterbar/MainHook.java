package com.example.alwaysletterbar;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.PathInterpolator;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 魅族桌面「边缘滑动应用搜索」字母条常显。
 *
 * 原理:
 *  原版 ASearchLayout(整屏浮层,内含字母条 + 应用分组列表) 平时是 GONE,
 *  显示/隐藏通过对整个浮层做 alpha 动画。
 *  这里让 ASearchLayout 本身永远 VISIBLE(字母条因此常显),
 *  把原来对整个浮层的显示/隐藏动画,改为只对「应用分组列表」(mGroupLayout) 做。
 *  边缘滑动手势、选字母、打开应用等原逻辑完全不动。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[AlwaysLetterBar] ";
    private static final String PKG = "com.meizu.flyme.launcher";
    private static final String P = "com.meizu.flyme.launcher.slideappsearch.";
    private static final String LAYOUT = P + "ASearchLayout";
    private static final String IMPL = P + "MzSlideAppsSearchPhoneImpl";

    private static final long SHOW_MS = 250;
    private static final long HIDE_MS = 200;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (!PKG.equals(lp.packageName)) return;
        ClassLoader cl = lp.classLoader;

        hookSafely("ASearchLayout.<init>", () ->
                XposedHelpers.findAndHookConstructor(LAYOUT, cl, Context.class, AttributeSet.class,
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam p) {
                                setupIdle((View) p.thisObject);
                            }
                        }));

        hookSafely("animateShow", () ->
                XposedHelpers.findAndHookMethod(LAYOUT, cl, "animateShow", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        p.setResult(null);
                        show((View) p.thisObject);
                    }
                }));

        hookSafely("animateHide", () ->
                XposedHelpers.findAndHookMethod(LAYOUT, cl, "animateHide", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        p.setResult(null);
                        hide((View) p.thisObject);
                    }
                }));

        hookSafely("noAnimateHide", () ->
                XposedHelpers.findAndHookMethod(LAYOUT, cl, "noAnimateHide", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        p.setResult(null);
                        setupIdle((View) p.thisObject);
                    }
                }));

        // 用户在 Flyme 设置里关闭「滑动应用搜索」/简易模式时,字母条也一起隐藏
        hookSafely("PhoneImpl.initialize", () ->
                XposedHelpers.findAndHookMethod(IMPL, cl, "initialize",
                        "com.meizu.flyme.launcher.MzLauncher", new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam p) {
                                applyEnabled(p.thisObject);
                            }
                        }));

        hookSafely("PhoneImpl.setEnable", () ->
                XposedHelpers.findAndHookMethod(IMPL, cl, "setEnable", boolean.class,
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam p) {
                                applyEnabled(p.thisObject);
                            }
                        }));

        // 应用列表更新后重绘字母条
        hookSafely("PhoneImpl.onAppsUpdate", () ->
                XposedHelpers.findAndHookMethod(IMPL, cl, "onAppsUpdate", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            Object layout = XposedHelpers.getObjectField(p.thisObject, "mAppsSearchLayout");
                            if (layout == null) return;
                            View bar = (View) XposedHelpers.getObjectField(layout, "mLetterBarView");
                            if (bar != null) bar.postInvalidate();
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + t);
                        }
                    }
                }));

        XposedBridge.log(TAG + "hooks installed");
    }

    /** 待机态: 浮层常显(字母条可见),应用分组列表隐藏。 */
    private static void setupIdle(View layout) {
        try {
            layout.setVisibility(View.VISIBLE);
            layout.setAlpha(1f);
            View group = (View) XposedHelpers.getObjectField(layout, "mGroupLayout");
            if (group != null) {
                group.animate().cancel();
                group.setAlpha(0f);
                group.setVisibility(View.GONE);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "setupIdle: " + t);
        }
    }

    private static void show(View layout) {
        try {
            XposedHelpers.setBooleanField(layout, "mIsShowing", true);
            layout.setVisibility(View.VISIBLE);
            layout.setAlpha(1f);
            View group = (View) XposedHelpers.getObjectField(layout, "mGroupLayout");
            if (group == null) return;
            group.animate().cancel();
            group.setVisibility(View.VISIBLE);
            group.animate()
                    .alpha(1f)
                    .setDuration(SHOW_MS)
                    .setInterpolator(new PathInterpolator(0.33f, 0f, 0.67f, 1f))
                    .start();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "show: " + t);
        }
    }

    private static void hide(final View layout) {
        try {
            XposedHelpers.setBooleanField(layout, "mIsShowing", false);
            final View group = (View) XposedHelpers.getObjectField(layout, "mGroupLayout");
            if (group == null) return;
            group.animate().cancel();
            group.animate()
                    .alpha(0f)
                    .setDuration(HIDE_MS)
                    .setInterpolator(new PathInterpolator(0.33f, 0f, 0.67f, 1f))
                    .withEndAction(() -> {
                        // 动画期间若又被重新显示,不要隐藏
                        if (!XposedHelpers.getBooleanField(layout, "mIsShowing")) {
                            group.setVisibility(View.GONE);
                        }
                    })
                    .start();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hide: " + t);
        }
    }

    /** mTouchArea > 0 表示功能启用;否则隐藏字母条。 */
    private static void applyEnabled(Object impl) {
        try {
            Object layout = XposedHelpers.getObjectField(impl, "mAppsSearchLayout");
            if (layout == null) return;
            View bar = (View) XposedHelpers.getObjectField(layout, "mLetterBarView");
            if (bar == null) return;
            boolean enabled = XposedHelpers.getIntField(impl, "mTouchArea") > 0;
            bar.setVisibility(enabled ? View.VISIBLE : View.INVISIBLE);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "applyEnabled: " + t);
        }
    }

    private interface Hooker { void run() throws Throwable; }

    private static void hookSafely(String name, Hooker h) {
        try {
            h.run();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook failed: " + name + " -> " + t);
        }
    }
}
